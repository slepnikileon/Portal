from django.contrib import admin
from .models import Access


admin.site.register(Access)

# Register your models here.
